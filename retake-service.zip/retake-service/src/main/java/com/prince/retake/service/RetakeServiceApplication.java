package com.prince.retake.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetakeServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetakeServiceApplication.class, args);
	}

}
