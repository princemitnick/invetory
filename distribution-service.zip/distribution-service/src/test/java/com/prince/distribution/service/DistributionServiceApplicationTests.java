package com.prince.distribution.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
